# coding=utf-8
# @Time    : 2022/1/4
# @Author  : Yi Chen
from zlgcan import *
dev = {
	"type_devcie": ZCAN_USBCANFD_MINI
}